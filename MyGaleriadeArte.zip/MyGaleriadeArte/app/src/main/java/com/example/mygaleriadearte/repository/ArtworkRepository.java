package com.example.mygaleriadearte.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.artgallery.dao.ArtworkDao;
import com.example.artgallery.database.ArtworkDatabase;
import com.example.artgallery.model.Artwork;

import java.util.List;

public class ArtworkRepository {
    private ArtworkDao artworkDao;
    private LiveData<List<Artwork>> allArtworks;

    public ArtworkRepository(Application application) {
        ArtworkDatabase database = ArtworkDatabase.getInstance(application);
        artworkDao = database.artworkDao();
        allArtworks = artworkDao.getAllArtworks();
    }

    public void insert(Artwork artwork) {
        new Thread(() -> artworkDao.insert(artwork)).start();
    }

    public LiveData<List<Artwork>> getAllArtworks() {
        return allArtworks;
    }
}
