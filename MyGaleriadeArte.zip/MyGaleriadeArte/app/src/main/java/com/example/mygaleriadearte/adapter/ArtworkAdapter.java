package com.example.mygaleriadearte.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.artgallery.R;
import com.example.artgallery.model.Artwork;

import java.util.List;

public class ArtworkAdapter extends RecyclerView.Adapter<ArtworkAdapter.ArtworkViewHolder> {
    private Context context;
    private List<Artwork> artworks;

    public ArtworkAdapter(Context context, List<Artwork> artworks) {
        this.context = context;
        this.artworks = artworks;
    }

    @NonNull
    @Override
    public ArtworkViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_artwork, parent, false);
        return new ArtworkViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ArtworkViewHolder holder, int position) {
        Artwork artwork = artworks.get(position);
        holder.textViewName.setText(artwork.getName());
        holder.textViewAuthor.setText(artwork.getAuthor());
        holder.textViewDescription.setText(artwork.getDescription());
        // Para cargar la imagen, usa una biblioteca como Glide o Picasso
        // Glide.with(context).load(artwork.getImagePath()).into(holder.imageViewArtwork);
    }

    @Override
    public int getItemCount() {
        return artworks.size();
    }

    public static class ArtworkViewHolder extends RecyclerView.ViewHolder {
        TextView textViewName, textViewAuthor, textViewDescription;
        ImageView imageViewArtwork;

        public ArtworkViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.textViewName);
            textViewAuthor = itemView.findViewById(R.id.textViewAuthor);
            textViewDescription = itemView.findViewById(R.id.textViewDescription);
            imageViewArtwork = itemView.findViewById(R.id.imageViewArtwork);
        }
    }
}
