package com.example.mygaleriadearte;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.artgallery.database.ArtworkDatabase;
import com.example.artgallery.model.Artwork;

public class AddArtworkActivity extends AppCompatActivity {
    private EditText editTextName, editTextDescription, editTextAuthor;
    private Button buttonUploadImage, buttonSaveArtwork;
    private ImageView imageViewPreview;
    private String imagePath = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_artwork);

        editTextName = findViewById(R.id.editTextName);
        editTextDescription = findViewById(R.id.editTextDescription);
        editTextAuthor = findViewById(R.id.editTextAuthor);
        buttonUploadImage = findViewById(R.id.buttonUploadImage);
        buttonSaveArtwork = findViewById(R.id.buttonSaveArtwork);
        imageViewPreview = findViewById(R.id.imageViewPreview);

        // Subir imagen
        buttonUploadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();
            }
        });

        // Guardar obra
        buttonSaveArtwork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveArtwork();
            }
        });
    }

    private void selectImage() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            Uri selectedImageUri = data.getData();
            if (selectedImageUri != null) {
                imagePath = selectedImageUri.toString();
                imageViewPreview.setImageURI(selectedImageUri);
                imageViewPreview.setVisibility(View.VISIBLE);
            }
        }
    }

    private void saveArtwork() {
        String name = editTextName.getText().toString().trim();
        String description = editTextDescription.getText().toString().trim();
        String author = editTextAuthor.getText().toString().trim();

        if (name.isEmpty() || description.isEmpty() || author.isEmpty() || imagePath.isEmpty()) {
            Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        Artwork artwork = new Artwork(name, description, author, imagePath);
        ArtworkDatabase.getInstance(this).artworkDao().insertArtwork(artwork);
        Toast.makeText(this, "Obra guardada exitosamente", Toast.LENGTH_SHORT).show();
        finish();
    }
}
