package com.example.mygaleriadearte.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.artgallery.model.Artwork;
import com.example.artgallery.repository.ArtworkRepository;

import java.util.List;

public class ArtworkViewModel extends AndroidViewModel {
    private ArtworkRepository repository;
    private LiveData<List<Artwork>> allArtworks;

    public ArtworkViewModel(Application application) {
        super(application);
        repository = new ArtworkRepository(application);
        allArtworks = repository.getAllArtworks();
    }

    public void insert(Artwork artwork) {
        repository.insert(artwork);
    }

    public LiveData<List<Artwork>> getAllArtworks() {
        return allArtworks;
    }
}
