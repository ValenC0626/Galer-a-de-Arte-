package com.example.mygaleriadearte.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.artgallery.dao.ArtworkDao;
import com.example.artgallery.model.Artwork;

@Database(entities = {Artwork.class}, version = 1, exportSchema = false)
public abstract class ArtworkDatabase extends RoomDatabase {
    private static ArtworkDatabase instance;

    public abstract ArtworkDao artworkDao();

    public static synchronized ArtworkDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            ArtworkDatabase.class, "artwork_database")
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }
}
